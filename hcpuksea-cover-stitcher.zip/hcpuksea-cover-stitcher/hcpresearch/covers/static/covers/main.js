
const submit = document.getElementById('submit'),
  resultHeading = document.getElementById('result-heading'),
  resultsEl = document.getElementById('results'),
  search = document.getElementById('search'),
  name = document.getElementById('name'),
  search_btn_icon = document.getElementById('search-icon');

function searchMeal(e) {
    e.preventDefault();
    // Get search term
    const isbns = search.value,
            list_name = name.value;
     this.getElementsByTagName("button")[0].disabled= true

    fetch(`/api/v1/process_images?q=${isbns}&name=${list_name}`)
        .then(res => res.json())
        .then(data => {
            submit.getElementsByTagName("button")[0].disabled= false
            resultsEl.insertAdjacentHTML('beforeend',
              `<div class="column">
                <div class="ui card">
                  <div class="image">
                    <img src="${data.url}" />
                  </div> 

                  <div class="content">
                      <a class="header">${data.name}</a>
                      <div class="meta">
                          <span class="date">${data.created_at}</span>
                      </div>
                      <div class="description">
                         ${data.count} books 
                      </div>
                  </div>
                </div>
              </div> <!-- /.column -->
            `);
        });
}

// Event listeners
submit.addEventListener('submit', searchMeal);