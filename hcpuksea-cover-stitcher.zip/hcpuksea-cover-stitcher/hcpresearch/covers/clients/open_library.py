"""
Open Library Client module to download book image
"""
import requests


class OpenLibraryClient:

    def __init__(self, base_url: str, timeout: int = 60):
        self.base_url = base_url
        self.timeout = timeout

    def download_cover(self, isbn: str, size: str):
        url = self.base_url.format(isbn=isbn, size=size)
        data = requests.get(url, stream=True, verify=False)
        if data.status_code == 200:
            return data
