import datetime
import os.path
from datetime import datetime

from django.conf import settings
from django.http import JsonResponse

from covers.collage.tree_view import TreeViewCollage
from covers.services.storage import LocalStorage
from covers.utils import generate_md5


def process_covers(request):
    isbns = request.GET.get('q')
    # generate md5 hash for all the isbn and save the thumbnail with the hash name to avoid recreating the image
    # for same isbn
    hash_md5 = generate_md5(isbns)
    isbns = isbns.split(",")
    fs = LocalStorage()
    collage_path = f"{settings.COLLAGE_FOLDER_NAME}/{hash_md5}.jpg"
    # check if there is collage available provided isbn
    if fs.is_exists(collage_path):
        url = fs.get_object_url(collage_path)
    else:
        collage = TreeViewCollage(isbns).generate_cover()
        collage.save(os.path.join(settings.MEDIA_ROOT, collage_path))
        url = fs.get_object_url(collage_path)

    return JsonResponse({
        "count": len(isbns),
        "name": request.GET.get('name'),
        "url": url,
        "created_at": datetime.now()}, safe=False)
