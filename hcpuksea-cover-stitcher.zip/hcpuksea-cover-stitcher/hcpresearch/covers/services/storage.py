"""
Local storage service to storage the book covers this is not for productions. The separate storage handler need to write
to store the image in dedicated file systems
"""
import os

from django.conf import settings


class LocalStorage:

    def save(self, data, name):
        path = os.path.join(settings.MEDIA_ROOT, name)
        directory = os.path.dirname(path)
        if not os.path.exists(directory):
            os.makedirs(directory)
        with open(path, 'wb') as f:
            for chunk in data:
                f.write(chunk)
        return path

    def get_object_url(self, name):
        return settings.MEDIA_URL + name

    def is_exists(self, path):
        path = os.path.join(settings.MEDIA_ROOT, path)
        return os.path.exists(path)
