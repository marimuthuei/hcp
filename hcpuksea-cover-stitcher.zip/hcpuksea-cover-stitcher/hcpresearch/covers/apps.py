from django.apps import AppConfig


class CoversConfig(AppConfig):
    name = 'covers'
