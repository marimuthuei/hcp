from pathlib import Path

from PIL import Image
from django.conf import settings

from covers.clients import OpenLibraryClient
from covers.services.storage import LocalStorage

"""
Module to create collage based on below patter which is like tree data structure.
    a
|------|                 |------|
|      |15%              |      |
|---   | x               |      |
30% |------|         |------|
    |      |         |      |
    |      | y       |      |    
        |------||------|
----------------------
total_w = 2x(a+x+y)
total_h= 15%of total_images
"""


class TreeViewCollage:
    TILE_W = 140
    TILE_H = 200
    OVERLAP_WIDTH = 30 / 100  # Move 30% of width for next image
    OVERLAP_HEIGHT = 15 / 100  # Move 15% of height for next image

    def __init__(self, isbns):
        self.fs = LocalStorage()
        self.open_library = OpenLibraryClient(settings.OPEN_LIBRARY_API)
        self.isbns = isbns

    def generate_cover(self):
        """
        the method generate the collage and returns the url of the image
        :return: collage file object
        """

        w, h = self.calculate_image_size()
        total_w = int(w + (w * 0.20))  # 20% margin width
        total_h = int(h + (h * .40))  # 40% margin height
        # start_x= 10% from left and start_y 20% from top
        start_x = int(w * 0.10)
        start_y = int(h * 0.20)
        self.create_tile(total_w, total_h, start_x, start_y)
        return self.collage

    def calculate_image_size(self):
        """
        Calculate the total width required for thumbnail generation. The left side width is calculated based on
        width = Tile width + 30% overlap in width for each image
        height = Tile height +15% overlap in height for each image
        :param n:
        :return:
        """
        w, h = self.TILE_W, self.TILE_H
        isbn_len = len(self.isbns)
        # split the no of images into half to form a left and right node.
        left_stack = isbn_len // 2
        # Exclude width calculation for centre page
        left_stack = left_stack - 1
        if isbn_len > 1:
            left_w = w + (left_stack * (w * self.OVERLAP_WIDTH))
            left_h = h + (left_stack * (h * self.OVERLAP_HEIGHT))
            # multiply with 2 for both the sides
            w = left_w * 2
            h = left_h
        return w, h

    def create_tile(self, width, height, start_x, start_y):
        """
        Creates a tree based collage by pasting next images by 30% and 15% and centre image by computing
        the total width of (left start width + right start width).
        :param width: image width
        :param height: image height
        :param start_x: start position in x-axis
        :param start_y: start position in y-axis
        :return:
        """

        self.collage = Image.new("RGB", (width, height), color=(255, 255, 255, 255))
        isbn_len = len(self.isbns)

        for x in range(0, isbn_len, 2):
            if x == isbn_len - 1:
                # calculate width and height for middle page
                centre_start_height = height * 0.08  # assumption leaving 8% from the top for centre page
                right_start_width = width - (start_x + self.TILE_W)
                cover_w = (right_start_width + self.TILE_W) - start_x
                cover_h = start_y + self.TILE_H - (centre_start_height)
                content = self.download_cover(self.isbns[x])
                # draw centre image
                self.draw_image(content, cover_w, cover_h, start_x, int(centre_start_height))
                return

            left_cover = self.download_cover(self.isbns[x])
            # draw left image
            self.draw_image(left_cover, self.TILE_W, self.TILE_H, start_x, start_y)
            right_cover = self.download_cover(self.isbns[x + 1])
            right_start_width = width - (start_x + self.TILE_W)
            # draw left image
            self.draw_image(right_cover, self.TILE_W, self.TILE_H, right_start_width, start_y)
            # move width and height to 30% to 15% respectively
            start_x = int(start_x + (self.TILE_W * self.OVERLAP_WIDTH))
            start_y = int(start_y + (self.TILE_H * self.OVERLAP_HEIGHT))

    def draw_image(self, content, w, h, x, y):
        photo = Image.open(content).convert("RGBA")
        photo = photo.resize((int(w), int(h)))
        self.collage.paste(photo, (int(x), int(y)))

    def download_cover(self, isbn):
        """
        Download the image from open library if not exists in our filesystem
        :param isbn: book isbn
        :return: local storage path
        """
        path = f"{settings.COVER_FOLDER_NAME}/{isbn}.jpg"
        if self.fs.is_exists(path):
            url = Path(settings.MEDIA_ROOT + path)
        else:
            content = self.open_library.download_cover(isbn, "M")
            url = Path(self.fs.save(content, path))
        return url
