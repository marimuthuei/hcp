import hashlib

def generate_md5(data):
    return hashlib.md5(data.encode('utf-8')).hexdigest()