from django.contrib import admin

# Register your models here.
# class BookCover
#     isbn =
#     cover =
#
#
#     def __str__(self):
#         return self.cover