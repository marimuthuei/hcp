from django.contrib import admin
from django.urls import path
from covers.views import index
from covers.api import process_covers
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', index),
    path('api/v1/process_images', process_covers),
]

urlpatterns += static(settings.MEDIA_URL,
                      document_root=settings.MEDIA_ROOT)
