## Cover Stitcher
The application creates a collage of book covers

##Info
Due to time constraint the application doesn't have error handling and logging mechanism and unit test cases.

### Packages
The application uses PIL library for collage creation. Other requirements are included in project.

### Prerequisites
Install the below requirements
- [python > 3.8](https://www.python.org/)



### Running the application
- Uzip the directory and cd hcpresearch folder.
    ```bash
    cd hcpresearch
    ```

- Setup venv and install requirements
    ```bash
    pip install -r requirements.txt
    ```
- Run the application.
    ```bash
    python manage.py runserver
    ```


#### Design considerations/Improvements for production

- Implement Error handling and log handler
- The cover images are currently stored in local filesystem where the app is running, this should be moved to external file systems
- The Book entity should be stored in db based on level of details need to be displayed.  
- async processing of the requests by implementing celery workers or event based system using messaging queues.
- Add caching to improve the latency.
- Use Authentication and Authorization.
